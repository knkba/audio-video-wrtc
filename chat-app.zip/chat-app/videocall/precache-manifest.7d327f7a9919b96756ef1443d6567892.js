self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e749814475c8f953f06b90ae98bbc3fe",
    "url": "./videocall/index.html"
  },
  {
    "revision": "0774024fb4c56232f41b",
    "url": "./videocall/static/css/main.b8afcf68.chunk.css"
  },
  {
    "revision": "43ffdd3ef2917cbccfb7",
    "url": "./videocall/static/js/2.549f06c4.chunk.js"
  },
  {
    "revision": "0774024fb4c56232f41b",
    "url": "./videocall/static/js/main.58dfaa50.chunk.js"
  },
  {
    "revision": "a6430c57e684ddc169ed",
    "url": "./videocall/static/js/runtime-main.ac378231.js"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "./videocall/static/media/fontawesome-webfont.674f50d2.eot"
  },
  {
    "revision": "912ec66d7572ff821749319396470bde",
    "url": "./videocall/static/media/fontawesome-webfont.912ec66d.svg"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "./videocall/static/media/fontawesome-webfont.af7ae505.woff2"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "./videocall/static/media/fontawesome-webfont.b06871f2.ttf"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "./videocall/static/media/fontawesome-webfont.fee66e71.woff"
  },
  {
    "revision": "448c34a56d699c29117adc64c43affeb",
    "url": "./videocall/static/media/glyphicons-halflings-regular.448c34a5.woff2"
  },
  {
    "revision": "89889688147bd7575d6327160d64e760",
    "url": "./videocall/static/media/glyphicons-halflings-regular.89889688.svg"
  },
  {
    "revision": "e18bbf611f2a2e43afc071aa2f4e1512",
    "url": "./videocall/static/media/glyphicons-halflings-regular.e18bbf61.ttf"
  },
  {
    "revision": "f4769f9bdb7466be65088239c12046d1",
    "url": "./videocall/static/media/glyphicons-halflings-regular.f4769f9b.eot"
  },
  {
    "revision": "fa2772327f55d8198301fdb8bcfc8158",
    "url": "./videocall/static/media/glyphicons-halflings-regular.fa277232.woff"
  }
]);